# 01 - Hex Encoding

## Laboratuvarın Adı
Hex Encoding

## Öğrenilmesi Amaçlanan Konu
Onaltılık (Hexadecimal / Base16) sayı sisteminde kodlanmış verilerin okunabilir düz metne (ASCII/UTF-8) dönüştürülmesi.

## Karşılaşılan Soru veya Görev
`hex_encoding.txt` dosyasında verilen kesintisiz onaltılık (hex) dizisinin düz metne çevrilmesi:

```text
54686542697274684F6656656E7573426F74746963656C6C69
```

## Verdiğim Cevap
```text
TheBirthOfVenusBotticelli
```

## Sorunun Nasıl Çözüldüğü
1. Verilen kesintisiz hexadecimal dize, her biri 1 baytı (1 ASCII karakterini) temsil edecek şekilde ikişerli gruplara (`54 68 65 42 ... 6C 69`) ayrıldı.
2. Çevrimiçi **dCode — ASCII Kodu (ASCII Dönüştürücü)** aracındaki *ASCII Şifreli Metin* alanına yapıştırılarak **Çöz/Dönüştür** işlemi çalıştırıldı.
3. Sonuç tablosunda **`HEX /2`** (ikişer basamaklı onaltılık okuma) satırından düz metin karşılığı elde edildi.

## Kullanılan Araç, Web Sitesi, Komut veya Yöntem
- **Web Sitesi / Araç:** [dCode — ASCII Kodu (ASCII Dönüştürücü)](https://www.dcode.fr/ascii-code) (`HEX /2` çözümleme modu)
- **Yöntem:** İki basamaklı hexadecimal baytların ASCII karakter tablosu üzerinden metne dönüştürülmesi.

## Kısa Teknik Açıklama
Hex Encoding (Base16), ikili (binary) veriyi `0–9` ve `A–F` karakterlerini kullanarak 16 tabanında temsil eder. Her 2 hexadecimal karakter 8 bite (1 bayta) karşılık gelir (örneğin `0x54` = onluk `84` = `'T'`). Şifreleme (encryption) değil, geri döndürülebilir bir veri temsili (encoding) yöntemidir ve gizlilik sağlamaz.

## Öğrenilenler
- Kesintisiz hex dizilerinin bayt sınırlarını (2 karakter = 1 bayt) koruyarak ayrıştırılması gerektiği kavrandı.
- Ağ paketleri, bellek dökümleri ve dosya başlıklarında (magic bytes) karşılaşılan hex verilerinin hızlıca metne dönüştürülmesi pekiştirildi.
