# 03 - ASCII

## Laboratuvarın Adı
ASCII

## Öğrenilmesi Amaçlanan Konu
Onluk (Decimal) tabanda verilen ASCII karakter kodlarının düz metne dönüştürülmesi.

## Karşılaşılan Soru veya Görev
`ascii.txt` dosyasında boşluklarla ayrılmış onluk ASCII sayı dizisinin çözümlenmesi:

```text
83 116 97 114 114 121 78 105 103 104 116 86 97 110 71 111 103 104
```

## Verdiğim Cevap
```text
StarryNightVanGogh
```

## Sorunun Nasıl Çözüldüğü
1. Boşluklarla ayrılmış ondalık sayı dizisi **dCode — ASCII Kodu (ASCII Dönüştürücü)** aracının giriş alanına aktarıldı.
2. **Çözme/Dönüştürme** işlemi çalıştırıldı ve sonuç listesindeki **`DEC /N`** (ondalık sayı dizisi çözümleme) satırından karakter karşılıkları okundu.

## Kullanılan Araç, Web Sitesi, Komut veya Yöntem
- **Web Sitesi / Araç:** [dCode — ASCII Kodu (ASCII Dönüştürücü)](https://www.dcode.fr/ascii-code) (`DEC /N` çözümleme modu)
- **Yöntem:** Ondalık (Decimal) ASCII kod tablosu eşleştirmesi.

## Kısa Teknik Açıklama
ASCII (American Standard Code for Information Interchange), metin karakterlerini `0–127` aralığındaki 7-bitlik sayısal değerlerle eşleyen temel karakter kodlama standardıdır (`65–90` büyük harfler `A–Z`, `97–122` küçük harfler `a–z`; örneğin `83` = `'S'`, `116` = `'t'`).

## Öğrenilenler
- Büyük ve küçük harflerin ASCII tablosundaki sayısal aralıkları (aralarındaki `32` birimlik fark dahil) pekiştirildi.
- Farklı sayı tabanlarında (`DEC`, `HEX`, `OCT`, `BIN`) temsil edilen verilerin aynı karakter kümesine işaret ettiği kavrandı.
