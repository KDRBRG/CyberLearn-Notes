# 06 - Binary

## Laboratuvarın Adı
Binary

## Öğrenilmesi Amaçlanan Konu
İkili (Binary / Base2) sayı sisteminde 8-bitlik bloklar halinde verilen verinin ASCII metne dönüştürülmesi.

## Karşılaşılan Soru veya Görev
`binary_encoding.txt` dosyasında verilen 8-bit ikili dizinin çözümlenmesi:

```text
01000111 01101001 01110010 01101100 01010111 01101001 01110100 01101000 01000001 01010000 01100101 01100001 01110010 01101100 01000101 01100001 01110010 01110010 01101001 01101110 01100111 01010110 01100101 01110010 01101101 01100101 01100101 01110010
```

## Verdiğim Cevap
```text
GirlWithAPearlEarringVermeer
```

## Sorunun Nasıl Çözüldüğü
1. 8-bitlik ikili bayt bloklarının her biri onluk (decimal) sayı sistemindeki karşılıklarına dönüştürüldü:
   ```text
   71 105 114 108 87 105 116 104 65 80 101 97 114 108 69 97 114 114 105 110 103 86 101 114 109 101 101 114
   ```
2. Elde edilen onluk ASCII dizisi **dCode — ASCII Kodu (ASCII Dönüştürücü)** aracının giriş alanına aktarılarak **Çöz/Dönüştür** işlemi çalıştırıldı.
3. Sonuç tablosundaki **`DEC /N`** satırından düz metin çıktısı okundu.

## Kullanılan Araç, Web Sitesi, Komut veya Yöntem
- **Web Sitesi / Araç:** [dCode — ASCII Kodu (ASCII Dönüştürücü)](https://www.dcode.fr/ascii-code) (`DEC /N` çözümleme modu)
- **Yöntem:** İki aşamalı taban dönüşümü (`8-bit Binary -> Onluk (Decimal) ASCII -> Düz Metin`).

## Kısa Teknik Açıklama
Binary kodlama, bilgisayar sistemlerinin en temel veri temsil biçimidir ve veriyi yalnızca `0` ile `1` bitleriyle ifade eder. Standart ASCII karakter kodlamasında her karakter 8 bitlik (1 bayt) bir ikili blokla temsil edilir (örneğin `01000111` = $64 + 4 + 2 + 1 = 71$ = `'G'`).

## Öğrenilenler
- 8-bit ikili blokların basamak değerleri ($2^7$–$2^0$) üzerinden onluk tabana ve ASCII karakterlerine dönüşüm mantığı pekiştirildi.
- Sayı tabanları (`Binary <-> Decimal <-> Hex <-> ASCII`) arasında geçiş yaparak veri çözümleme becerisi kazanıldı.
