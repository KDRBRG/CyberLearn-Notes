# 02 - URL Encoding

## Laboratuvarın Adı
URL Encoding

## Öğrenilmesi Amaçlanan Konu
Yüzde kodlaması (Percent-Encoding / URL Encoding) uygulanmış dizelerin çözümlenmesi ve arkasındaki hexadecimal yapının anlaşılması.

## Karşılaşılan Soru veya Görev
`url_encoding.txt` dosyasında verilen URL kodlu dizinin düz metne çevrilmesi:

```text
%54%68%65%53%63%72%65%61%6D%4D%75%6E%63%68
```

## Verdiğim Cevap
```text
TheScreamMunch
```

## Sorunun Nasıl Çözüldüğü
1. URL kodlu dizedeki her `%XX` ifadesinin bir karakterin ASCII hexadecimal değerini temsil ettiği belirlendi.
2. Dize doğrudan **dCode — ASCII Kodu (ASCII Dönüştürücü)** aracındaki *ASCII Şifreli Metin* alanına girilerek **Çöz/Dönüştür** işlemi uygulandı.
3. Araç, `%` ayırıcılarını dikkate alarak bayt çiftlerini çözümledi ve **`HEX /2`** satırında düz metin sonucunu üretti.

## Kullanılan Araç, Web Sitesi, Komut veya Yöntem
- **Web Sitesi / Araç:** [dCode — ASCII Kodu (ASCII Dönüştürücü)](https://www.dcode.fr/ascii-code) (`HEX /2` çözümleme modu)
- **Yöntem:** Percent-encoding (`%XX`) baytlarının ASCII karşılıklarına dönüştürülmesi.

## Kısa Teknik Açıklama
URL Encoding (RFC 3986), URI/URL yapılarında özel anlam taşıyan veya ASCII dışı karakterlerin güvenli biçimde iletilmesi için her baytı `%` işaretinin ardından gelen iki haneli hexadecimal değerle ifade eder (örneğin `%54` -> `0x54` -> `'T'`).

## Öğrenilenler
- URL Encoding ile Hex Encoding arasındaki doğrudan yapısal ilişki (`%XX` = `0xXX`) gözlemlendi.
- Web uygulama güvenliği (XSS, SQLi payload analizi ve HTTP parametre incelemeleri) süreçlerinde yüzde kodlu verilerin nasıl okunacağı öğrenildi.
