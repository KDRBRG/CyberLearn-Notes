# Hafta 02 — Kriptoloji Temelleri Laboratuvarları

Bu bölüm, **Siber Vatan** eğitimi **Hafta 02 — Kriptoloji Temelleri** kapsamında tamamlanan kodlama (encoding) ve özetleme (hashing) laboratuvar çalışmalarını içermektedir.

## Laboratuvar Listesi

| No | Laboratuvar Adı | Giriş Verisi (Özet) | Bulunan Cevap | Kullanılan Araç / Site | Dosya |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 01 | Hex Encoding | `5468654269727468...` | `TheBirthOfVenusBotticelli` | dCode (ASCII Dönüştürücü) | [01-Hex-Encoding.md](./01-Hex-Encoding.md) |
| 02 | URL Encoding | `%54%68%65%53%63%72...` | `TheScreamMunch` | dCode (ASCII Dönüştürücü) | [02-URL-Encoding.md](./02-URL-Encoding.md) |
| 03 | ASCII | `83 116 97 114 114...` | `StarryNightVanGogh` | dCode (ASCII Dönüştürücü) | [03-ASCII.md](./03-ASCII.md) |
| 04 | Base64 | `TW9uYUxpc2FEYVZpbmNp` | `MonaLisaDaVinci` | Calcify (Base64 Çözücü) | [04-Base64.md](./04-Base64.md) |
| 05 | Base32 | `KRUGKUDFOJZWS43U...` | `ThePersistenceOfMemoryDali` | Base32 Kodlayıcı Çözücü | [05-Base32.md](./05-Base32.md) |
| 06 | Binary | `01000111 01101001...` | `GirlWithAPearlEarringVermeer` | dCode (ASCII Dönüştürücü) | [06-Binary.md](./06-Binary.md) |
| 07 | SHA1 | `7610bae85f2b5306...` | `leonardo` | dCode (SHA-1 Kod Çözücü) | [07-SHA1.md](./07-SHA1.md) |
| 08 | MD5 | `8dbdda48fb8748d6...` | `simple` | dCode (MD5 Kod Çözücü) | [08-MD5.md](./08-MD5.md) |
