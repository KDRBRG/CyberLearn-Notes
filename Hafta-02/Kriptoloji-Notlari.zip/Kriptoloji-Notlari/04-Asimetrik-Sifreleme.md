# Asimetrik Şifreleme

Asimetrik kriptografi, matematiksel olarak ilişkili iki anahtar kullanır:

- **Açık anahtar (Public Key):** Paylaşılabilir.
- **Özel/gizli anahtar (Private Key):** Yalnızca sahibi tarafından korunmalıdır.

Asimetrik işlemler, simetrik şifrelemeye göre genellikle daha fazla hesaplama gerektirir. Bu nedenle gerçek sistemlerde çoğunlukla anahtar anlaşması veya küçük verilerin korunması için kullanılır; büyük veri akışı simetrik algoritmalarla şifrelenir.

## Asimetrik Algoritmalar

### RSA (Rivest–Shamir–Adleman)

- 1977'de Ron Rivest, Adi Shamir ve Leonard Adleman tarafından yayımlanmıştır.
- Şifreleme ve dijital imza amacıyla kullanılabilir.
- Güvenliği, uygun parametreler altında büyük sayıların çarpanlarına ayrılmasının zorluğuna dayanır.
- Güncel uygulamalarda RSA için en az 2048 bit anahtar uzunluğu yaygın alt sınırdır; kullanım amacına uygun güvenli dolgu şemaları (ör. OAEP, PSS) seçilmelidir.

### ECC (Elliptic Curve Cryptography)

- Eliptik eğri matematiğine dayanır.
- RSA'ya kıyasla daha kısa anahtarlarla benzer güvenlik düzeyleri sağlayabilir.
- Mobil ve IoT gibi kaynakları kısıtlı ortamlarda avantajlı olabilir.
- ECDH anahtar anlaşması, ECDSA dijital imza gibi farklı ECC tabanlı yöntemler bulunur.

### ElGamal

- Taher Elgamal tarafından 1985'te tanımlanmıştır.
- Ayrık logaritma probleminin zorluğuna dayanır.
- Şifreleme ve bazı imza şemalarının temelinde kullanılmıştır.

### DSA (Digital Signature Algorithm)

- NIST tarafından dijital imza standardı olarak yayımlanmıştır.
- Şifreleme için değil, dijital imza oluşturma ve doğrulama için tasarlanmıştır.
- Güncel standart ve uygulama tercihleri kontrol edilmelidir.

## Avantajlar ve Dezavantajlar

**Avantajlar**
- Açık anahtarın paylaşılması, gizli anahtarın doğrudan dağıtılması ihtiyacını azaltır.
- Dijital imza ve sertifika altyapılarını mümkün kılar.
- Kimlik doğrulama ve anahtar anlaşması süreçlerinde kullanılır.

**Dezavantajlar**
- Simetrik algoritmalara göre genellikle daha yavaştır.
- Daha fazla hesaplama kaynağı gerektirebilir.
- Açık anahtarın gerçekten doğru kişiye ait olduğunun doğrulanması gerekir.

## Açık Anahtar Altyapısı (PKI)

PKI, açık anahtarların kimliklerle güvenilir biçimde ilişkilendirilmesini sağlayan politika, süreç ve teknolojiler bütünüdür.

### Temel Bileşenler

1. **Sertifika Otoritesi (CA):** Dijital sertifikaları imzalayan ve yayımlayan güvenilir otorite.
2. **Kayıt Otoritesi (RA):** Sertifika başvurularında kimlik doğrulama ve kayıt süreçlerine yardımcı olan birim.
3. **Dijital sertifika:** Bir kimliği veya sistemi açık anahtarla ilişkilendiren, CA tarafından dijital olarak imzalanmış belge.
4. **Sertifika deposu:** Sertifikaların yayımlandığı veya saklandığı yapı.

## Dijital İmzalar

Dijital imza, mesajın veya belgenin bütünlüğünü ve imzalayan anahtarın sahipliğini doğrulamaya yardımcı olur. İmza oluşturulurken genellikle belgenin özeti hesaplanır ve özel anahtarla imzalanır. Alıcı, imzayı açık anahtarla doğrular ve belgenin özetini yeniden hesaplayarak karşılaştırır.

> **Teknik düzeltme:** Dijital imza, her algoritmada hash değerinin özel anahtarla basitçe “şifrelenmesi” değildir. RSA-PSS, ECDSA ve EdDSA gibi imza şemalarının kendilerine özgü imzalama ve doğrulama işlemleri vardır.

## Uygulama Alanları

- TLS bağlantılarında sertifika doğrulama ve anahtar anlaşması
- PGP ve S/MIME ile e-posta imzalama/şifreleme
- SSH anahtar tabanlı kimlik doğrulama
- VPN ve güvenli ağ bağlantıları
- Yazılım imzalama ve dijital belge doğrulama
