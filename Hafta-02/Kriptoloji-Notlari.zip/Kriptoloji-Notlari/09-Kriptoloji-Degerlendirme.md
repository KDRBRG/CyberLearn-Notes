# Kriptoloji Değerlendirme Sınavı

12 soruluk değerlendirme. Çoktan seçmeli sorularda doğru seçeneği işaretleyin; yazılı sorulara yanıt verin.

## Sorular

**1.** Bilginin gizliliğini, bütünlüğünü ve doğruluğunu korumak için matematiksel tekniklerin kullanıldığı bilim dalı hangisidir?

- A) Encryption
- B) Hashing
- C) Cryptology
- D) Decryption

**2.** Şifrelenmiş bilgiyi orijinal haline geri getirme işlemi hangisidir?

- A) Encryption
- B) Decryption
- C) Hashing
- D) Clear Text

**3.** Herkesin erişimine açık olan ve genellikle asimetrik kriptografide kullanılan anahtar hangisidir?

- A) Private Key
- B) Decryption
- C) Clear Text
- D) Public Key

**4.** Hangisi kriptografinin temel amaçlarından biri değildir?

- A) İnkâr edilebilirlik
- B) Gizlilik
- C) Bütünlük
- D) Kimlik doğrulama

**5.** Hangisi simetrik şifreleme algoritmalarından biri değildir?

- A) DES
- B) AES
- C) RC4
- D) RSA

**6.** “Simetrik şifreleme, iki farklı anahtar kullanarak veri şifreleme ve şifre çözme işlemlerinin yapıldığı bir yöntemdir.”

- A) Doğru
- B) Yanlış

**7.** Aşağıdakilerden hangisi hash algoritması değildir?

- A) MD5
- B) SHA-1
- C) RIPEMD-160
- D) BASE64

**8.** Dijital imza ve güvenli veri aktarımı gibi alanlarda kullanılan, güvenliği büyük sayıların çarpanlarına ayrılmasının zorluğuna dayanan asimetrik algoritmanın kısa adı nedir?

**9.** Aşağıdakilerden hangisi kriptografik protokol değildir?

- A) PGP
- B) Telnet
- C) SSH
- D) SSL/TLS

**10.** Yaygın olarak kullanılan kelime ve parolaları deneyerek şifreyi bulmayı amaçlayan saldırı türü hangisidir?

- A) Kaba kuvvet saldırısı
- B) Yan kanal saldırısı
- C) Sözlük saldırısı
- D) Bilinen açık metin saldırısı

**11.** `21232f297a57a5a743894a0e4a801fc3` MD5 hash değerinin bilinen karşılığı nedir?

**12.** `aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d` SHA-1 hash değerinin bilinen karşılığı nedir?

---

## Cevap Anahtarı

| Soru | Cevap |
|---|---|
| 1 | C — Cryptology (Kriptoloji) |
| 2 | B — Decryption (Şifre çözme) |
| 3 | D — Public Key (Açık anahtar) |
| 4 | A — İnkâr edilebilirlik |
| 5 | D — RSA |
| 6 | B — Yanlış |
| 7 | D — BASE64 |
| 8 | RSA |
| 9 | B — Telnet |
| 10 | C — Sözlük saldırısı |
| 11 | `admin` |
| 12 | `hello` |

## Sınav Notları

- 11. sorudaki değer, `admin` metninin MD5 özetidir.
- 12. sorudaki değer, `hello` metninin SHA-1 özetidir.
- MD5 ve SHA-1 örnekleri yalnızca hash kavramını öğretmek içindir; güncel güvenlik tasarımlarında kullanılmaları önerilmez.
- Telnet, verileri varsayılan olarak şifrelemeden ilettiği için güvenli uzaktan erişim protokolü değildir.
