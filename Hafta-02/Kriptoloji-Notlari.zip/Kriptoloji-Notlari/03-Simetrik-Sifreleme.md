# Simetrik Şifreleme

Simetrik şifrelemede veriyi şifrelemek ve çözmek için aynı gizli anahtar kullanılır. Gönderen ve alıcı bu anahtarı güvenli biçimde paylaşmalıdır. Simetrik algoritmalar genellikle hızlıdır; temel zorluklardan biri anahtarın güvenli dağıtılması ve yönetilmesidir.

## Simetrik Şifreleme Türleri

### Blok Şifreler (Block Cipher)

Veri sabit boyutlu bloklar halinde işlenir.

#### DES (Data Encryption Standard)

- 1970'lerde IBM tarafından geliştirildi ve 1977'de standartlaştırıldı.
- Etkin anahtar uzunluğu 56 bittir.
- Kaba kuvvet saldırılarına karşı yetersiz kaldığı için güvenli kabul edilmez.

#### 3DES (Triple DES)

- DES işlemini üç aşamalı biçimde uygular.
- Genellikle 168 bit anahtar malzemesiyle anılsa da etkin güvenlik seviyesi daha düşüktür.
- Eski sistemlerle uyumluluk amacıyla kullanılmıştır; artık yeni sistemler için önerilmez ve standartlardan çekilmiştir.

#### AES (Advanced Encryption Standard)

- NIST tarafından 2001'de standartlaştırılmıştır.
- 128 bit blok boyutuna sahiptir; anahtar uzunlukları 128, 192 ve 256 bittir.
- Günümüzde yaygın kullanılan güçlü bir blok şifreleme standardıdır.

### Akış Şifreleri (Stream Cipher)

Veriyi bit veya bayt akışı olarak işler.

#### RC4

- Ron Rivest tarafından geliştirilmiştir.
- Tarihsel olarak WEP ve eski TLS uygulamalarında kullanılmıştır.
- Önemli güvenlik zayıflıkları nedeniyle artık güvenli kabul edilmez.

#### Salsa20 ve ChaCha20

- Modern, hızlı akış şifreleridir.
- ChaCha20, özellikle yazılım tabanlı uygulamalarda ve kısıtlı donanımlarda kullanılabilir.
- Genellikle Poly1305 gibi bir doğrulama mekanizmasıyla birlikte ChaCha20-Poly1305 AEAD yapısında kullanılır.

## Avantajlar ve Dezavantajlar

### Avantajlar

- Asimetrik yöntemlere kıyasla genellikle daha hızlıdır.
- Büyük miktarda veriyi şifrelemek için verimlidir.
- Donanım ve yazılım desteği yaygındır.

### Dezavantajlar

- Gizli anahtarın taraflar arasında güvenli paylaşılması gerekir.
- Çok sayıda kullanıcı olduğunda anahtar yönetimi karmaşıklaşır.
- Anahtarın ele geçirilmesi, o anahtarla korunan verileri tehlikeye atar.

## Blok Şifreleme Modları

- **ECB (Electronic Codebook):** Her blok bağımsız şifrelenir. Aynı açık metin blokları aynı şifreli blokları oluşturabildiği için veri desenlerini açığa çıkarabilir; güvenli kullanım için uygun değildir.
- **CBC (Cipher Block Chaining):** Her açık metin bloğu, önceki şifreli blokla XOR işleminden geçirilir. İlk blokta IV kullanılır. Tek başına bütünlük doğrulaması sağlamaz.
- **CFB (Cipher Feedback):** Blok şifreyi akış benzeri biçimde kullanır.
- **OFB (Output Feedback):** Şifreleme çıktısından bir anahtar akışı üretir; aynı akış şifreleme ve çözmede kullanılır.
- **CTR (Counter):** Sayaç değerleri şifrelenerek anahtar akışı elde edilir. Uygun koşullarda bloklar paralel işlenebilir.

> **Güncel güvenlik notu:** Yeni uygulamalarda AES-GCM gibi doğrulanmış şifreleme (AEAD) modları tercih edilir. CBC, CTR, CFB ve OFB gibi modlar tek başlarına bütünlük sağlamaz; doğru bir doğrulama mekanizması olmadan kullanılmamalıdır. IV/nonce tekrarının önlenmesi kritik önemdedir.

## Kullanım Alanları

- Dosya ve disk şifreleme
- VPN ve güvenli ağ iletişimi
- TLS gibi protokollerde oturum verisinin korunması
- Veritabanı ve yedeklerin şifrelenmesi
