# Kriptoloji Notları

Siber güvenlik ve kriptoloji alanındaki öğrenme notları.

## İçindekiler

1. [Kriptolojiye Giriş](01-Kriptolojiye-Giris.md)
2. [Kriptografi ve Kriptoanaliz](02-Kriptografi-ve-Kriptoanaliz.md)
3. [Simetrik Şifreleme](03-Simetrik-Sifreleme.md)
4. [Asimetrik Şifreleme](04-Asimetrik-Sifreleme.md)
5. [Hash Fonksiyonları ve Algoritmaları](05-Hash-Fonksiyonlari.md)
6. [Dijital İmzalar ve Sertifikalar](06-Dijital-Imzalar-ve-Sertifikalar.md)
7. [Kriptografik Protokoller](07-Kriptografik-Protokoller.md)
8. [Kriptoanaliz Teknikleri](08-Kriptoanaliz-Teknikleri.md)
9. [Değerlendirme Sınavı ve Cevap Anahtarı](09-Kriptoloji-Degerlendirme.md)

## Kapsam

Notlar; kriptolojinin temel kavramlarını, simetrik ve asimetrik şifrelemeyi, hash fonksiyonlarını, dijital imzaları, PKI yapısını, güvenli iletişim protokollerini ve kriptoanaliz tekniklerini kapsar.

## Önemli güvenlik notları

- DES, 3DES, RC4, MD5 ve SHA-1 güncel güvenlik uygulamalarında yeni tasarımlar için tercih edilmemelidir.
- Parolalar doğrudan hızlı hash algoritmalarıyla saklanmamalıdır. Argon2id, scrypt, bcrypt veya uygun yapılandırılmış PBKDF2 gibi parola hashleme algoritmaları ve benzersiz salt kullanılmalıdır.
- Yeni uygulamalarda mümkün olduğunda AES-GCM veya ChaCha20-Poly1305 gibi doğrulanmış şifreleme (AEAD) yöntemleri tercih edilmelidir.
- SSL artık güvenli kabul edilmez; güncel sistemlerde TLS kullanılmalıdır.
- Kriptografik güvenlik yalnızca algoritmaya değil, anahtar yönetimine ve doğru uygulamaya da bağlıdır.
