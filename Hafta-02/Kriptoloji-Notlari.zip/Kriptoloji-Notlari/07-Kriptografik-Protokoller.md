# Kriptografik Protokoller

Kriptografik protokol, iki veya daha fazla taraf arasında güvenli iletişim, kimlik doğrulama, anahtar anlaşması ve veri bütünlüğü sağlamak için tanımlanan kurallar bütünüdür. Protokoller, kriptografik algoritmaların hangi sırayla ve hangi koşullarda kullanılacağını belirler.

## Önemli Kriptografik Protokoller

### 1. SSL/TLS

- **Amaç:** Ağ üzerinden iletişimin gizliliğini, bütünlüğünü ve gerektiğinde tarafların kimlik doğrulamasını sağlamak.
- **Kullanım:** HTTPS bağlantıları.
- **Çalışma:** El sıkışma sürecinde taraflar algoritma parametrelerini belirler, sunucu sertifikası doğrulanabilir ve oturum anahtarları oluşturulur. Ardından simetrik şifreleme ile veri aktarılır.
- **Bileşenler:** Sertifikalar, anahtar anlaşması, simetrik şifreleme ve bütünlük/doğrulama mekanizmaları.

> **Güncel not:** SSLv2 ve SSLv3 güvensiz ve kullanımdan kalkmış protokollerdir. Güncel sistemlerde TLS 1.2 veya TLS 1.3 tercih edilmelidir.

### 2. IPsec

- **Amaç:** IP katmanında ağ trafiğini korumak.
- **Kullanım:** VPN ve ağlar arası güvenli iletişim.
- **ESP (Encapsulating Security Payload):** Gizlilik ve yapılandırmaya bağlı olarak bütünlük/kimlik doğrulama sağlar.
- **AH (Authentication Header):** Paket bütünlüğü ve kaynak doğrulaması sağlar; gizlilik sağlamaz.
- **IKE (Internet Key Exchange):** Anahtar değişimi ve güvenlik ilişkilerinin kurulmasını yönetir.

### 3. SSH (Secure Shell)

- **Amaç:** Uzak sistemlere güvenli erişim ve yönetim.
- **Kullanım:** Sunucu, yönlendirici ve ağ cihazlarının yönetimi.
- **Çalışma:** Anahtar değişimiyle güvenli oturum kurulur; kullanıcı parola veya açık anahtar tabanlı yöntemlerle doğrulanabilir; oturum trafiği şifrelenir.

### 4. PGP / OpenPGP

- **Amaç:** E-posta ve dosyaların şifrelenmesi ve dijital olarak imzalanması.
- **Çalışma:** Mesaj çoğunlukla simetrik bir oturum anahtarıyla şifrelenir; oturum anahtarı alıcının açık anahtarıyla korunur. İmza için gönderenin özel anahtarı kullanılır.

### 5. Kerberos

- **Amaç:** Ağ ortamında merkezi ve güvenli kimlik doğrulama.
- **Kullanım:** Kurumsal ağlar ve hizmetler.
- **Çalışma:** Key Distribution Center (KDC) içindeki Authentication Server ve Ticket Granting Server bileşenleri bilet (ticket) sağlar. Kullanıcı, hizmete erişirken ilgili hizmet biletini kullanır.
- **Temel yapı:** Simetrik anahtarlar, biletler ve zaman damgaları.

### 6. OAuth 2.0

- **Amaç:** Bir uygulamanın, kullanıcının yetkilendirdiği kaynaklara sınırlı erişim elde etmesini sağlamak.
- **Kullanım:** Web ve mobil uygulamalarda üçüncü taraf erişimi.
- **Çalışma:** Yetkilendirme akışları sonucunda erişim belirteci (access token) elde edilir ve korunan kaynaklara erişimde kullanılır.

> **Önemli ayrım:** OAuth 2.0 bir yetkilendirme çerçevesidir; tek başına kimlik doğrulama protokolü değildir. Kullanıcı kimliğini doğrulamak için OpenID Connect gibi bir katman kullanılabilir.

## Protokol Güvenliği

- Güncel ve güvenli algoritmalar ile protokol sürümleri kullanılmalıdır.
- Anahtarlar güvenli biçimde oluşturulmalı, saklanmalı ve yenilenmelidir.
- Yazılım ve protokol uygulamaları güncel tutulmalıdır.
- Sertifikalar ve sunucu kimlikleri doğru doğrulanmalıdır.
- Protokoller standartlara uygun yapılandırılmalıdır.

## Kullanım Alanları

- **Web güvenliği:** HTTPS/TLS
- **Ağ güvenliği:** IPsec VPN
- **Uzaktan yönetim:** SSH
- **E-posta güvenliği:** OpenPGP ve S/MIME
- **Kurumsal kimlik doğrulama:** Kerberos
- **Yetkilendirme:** OAuth 2.0
