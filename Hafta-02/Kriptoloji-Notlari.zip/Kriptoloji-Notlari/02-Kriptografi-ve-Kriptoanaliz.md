# Kriptografi ve Kriptoanaliz

## Kriptografi Nedir?

Kriptografi, bilgiyi güvenli biçimde iletmek ve saklamak için matematiksel yöntemler ve algoritmalar kullanır.

### Kriptografinin Temel Güvenlik Amaçları

- **Gizlilik (Confidentiality):** Bilgiyi yalnızca yetkili kişilerin okuyabilmesini sağlamak.
- **Bütünlük (Integrity):** Bilginin yetkisiz veya istenmeyen biçimde değiştirilmesini tespit etmek ya da önlemek.
- **Kimlik doğrulama (Authentication):** Kullanıcının, cihazın veya mesaj kaynağının kimliğini doğrulamak.
- **İnkâr edilemezlik (Non-repudiation):** Uygun koşullarda, bir işlemin veya imzanın belirli bir tarafla ilişkilendirilmesini ve sonradan inkâr edilmesinin zorlaştırılmasını sağlamak.

### Kriptografi Türleri

1. **Simetrik kriptografi:** Şifreleme ve şifre çözme için aynı gizli anahtar kullanılır.
2. **Asimetrik kriptografi:** Matematiksel olarak ilişkili açık ve özel anahtar çifti kullanılır. Kullanım amacına göre şifreleme veya dijital imza gerçekleştirilebilir.

## Kriptoanaliz Nedir?

Kriptoanaliz, kriptografik algoritma ve protokollerin güvenliğini inceleyen; bunların zayıflıklarını ve saldırılara karşı dayanıklılığını değerlendiren alandır. Yetkili güvenlik testlerinde sistemleri güçlendirmek amacıyla kullanılır.

### Kriptoanaliz Türleri

- **Kırma saldırıları:** Şifreli veriyi çözmeye veya anahtarı elde etmeye yönelik girişimler.
- **Analiz saldırıları:** Algoritma, protokol, uygulama veya anahtar yönetimindeki zayıflıkları inceleyen yöntemler.

## Kriptografi ve Kriptoanaliz Arasındaki Fark

| Başlık | Kriptografi | Kriptoanaliz |
|---|---|---|
| Temel amaç | Bilgiyi korumak | Koruma mekanizmasının dayanıklılığını sınamak |
| Odak | Güvenli algoritma ve protokol tasarımı | Zayıflık ve saldırı analizi |
| Kullanım | Güvenli iletişim ve veri saklama | Güvenlik değerlendirmesi ve araştırma |

## Temel Prensipler

### Kerckhoffs İlkesi

Bir kriptosistemin güvenliği, algoritmanın gizli tutulmasına değil, anahtarın gizliliğine dayanmalıdır. Algoritma kamuya açık olsa bile sistem güvenli kalabilmelidir.

### Shannon'ın Yaklaşımı

Claude Shannon'ın bilgi kuramı çalışmaları, kriptografik güvenliğin matematiksel olarak incelenmesinde temel oluşturur. İdeal gizlilik (perfect secrecy) ve belirsizlik gibi kavramlar bu alandadır. Her şifreli metnin mutlaka tamamen rastgele görünmesi gerektiği şeklindeki basitleştirilmiş ifade, Shannon'ın teorisinin tam karşılığı değildir.

## Kriptoanaliz Tekniklerine Örnekler

- **Kaba kuvvet (Brute Force):** Olası anahtarların sistematik biçimde denenmesi.
- **Sözlük saldırısı (Dictionary Attack):** Yaygın parola ve kelimelerin denenmesi.
- **Yan kanal saldırısı (Side-Channel):** Zamanlama, güç tüketimi veya elektromanyetik sızıntı gibi fiziksel bilgilerin incelenmesi.
- **İstatistiksel analiz:** Şifreli verideki istatistiksel örüntülerden yararlanılması.

Kriptografi ve kriptoanaliz birbirini tamamlar: Kriptoanalizden elde edilen bulgular daha dayanıklı algoritma ve uygulamaların geliştirilmesine katkı sağlar.
