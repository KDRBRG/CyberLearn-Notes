# Kriptolojiye Giriş

## Kriptoloji Nedir?

Kriptoloji, bilginin gizliliğini, bütünlüğünü ve doğruluğunu korumak için matematiksel yöntemlerden yararlanan bilim dalıdır. İki temel alana ayrılır:

- **Kriptografi:** Bilgiyi korumak için şifreleme, dijital imza ve benzeri yöntemleri tasarlar ve inceler.
- **Kriptoanaliz:** Kriptografik sistemlerin güvenliğini inceler; zayıflıkları ve olası saldırı yollarını araştırır.

## Kriptolojinin Tarihçesi

Kriptografik yöntemler eski uygarlıklardan beri kullanılmaktadır. Eski Mısır'da standart dışı yazı biçimleri, Roma döneminde ise Sezar şifresi gibi yöntemler görülür. Modern kriptolojinin gelişiminde 20. yüzyıl, özellikle İkinci Dünya Savaşı sırasında kullanılan Enigma ve Alan Turing'in çalışmalarının da etkisiyle önemli bir dönem olmuştur. Günümüzde kriptoloji; internet iletişimi, dijital kimlik, finans ve veri saklama güvenliğinin temel bileşenlerinden biridir.

## Önemi ve Kullanım Alanları

- **İletişim güvenliği:** İnternet üzerinden aktarılan verilerin gizliliği ve bütünlüğü.
- **Veri depolama:** Dosya, disk ve veri tabanlarının korunması.
- **Kimlik doğrulama:** Dijital sertifikalar ve imzalar aracılığıyla kimlik veya kaynak doğrulama.
- **Finansal işlemler:** Bankacılık ve e-ticaret işlemlerinin korunması.
- **Devlet ve askerî uygulamalar:** Hassas bilgilerin korunması.

## Temel Terimler

### Şifreleme ve Şifre Çözme

- **Şifreleme (Encryption):** Açık metnin, algoritma ve anahtar kullanılarak şifreli metne dönüştürülmesidir.
- **Şifre çözme (Decryption):** Şifreli metnin uygun anahtar ve algoritmayla tekrar açık metne dönüştürülmesidir.

### Anahtar ve Anahtar Yönetimi

- **Anahtar (Key):** Kriptografik algoritmanın işlemlerini kontrol eden değerdir.
- **Anahtar yönetimi (Key Management):** Anahtarların üretilmesi, dağıtılması, saklanması, kullanılması, yenilenmesi ve güvenli biçimde yok edilmesi süreçleridir.

### Açık ve Gizli Anahtar

- **Açık anahtar (Public Key):** Asimetrik kriptografide paylaşılabilen anahtardır.
- **Gizli/özel anahtar (Private Key):** Yalnızca sahibi tarafından korunması gereken anahtardır.

### Algoritmalar ve Protokoller

- **Kriptografik algoritma:** Şifreleme, özetleme veya imzalama gibi işlemleri gerçekleştiren matematiksel yöntemdir. AES, RSA ve SHA-256 örnek verilebilir.
- **Kriptografik protokol:** Birden fazla tarafın kriptografik algoritmaları hangi sırayla ve hangi kurallarla kullanacağını tanımlar. TLS, SSH ve IPsec örnektir.

> **Not:** Hash fonksiyonları şifreleme değildir. Hash işlemi tek yönlü özet üretir; normal bir şifre çözme işlemiyle özgün veriye dönülmez.
