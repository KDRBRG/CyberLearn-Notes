# Kriptoanaliz Teknikleri

Kriptoanaliz, şifreleme sistemlerinin güvenliğini değerlendirmek ve olası zayıflıklarını ortaya çıkarmak için kullanılan yöntemleri inceler. Bu teknikler yetkili güvenlik araştırmalarında sistemleri güçlendirmek amacıyla kullanılabilir.

## Kriptoanaliz Teknikleri

### 1. Kaba Kuvvet Saldırısı (Brute Force)

- **Tanım:** Olası anahtarların sistematik olarak denenmesidir.
- **Özellik:** Anahtar uzunluğu ve anahtar uzayının büyüklüğü arttıkça gereken işlem miktarı artar.
- **Savunma:** Yeterince uzun anahtarlar, güncel algoritmalar ve uygun hız sınırlamaları kullanmak.

### 2. Sözlük Saldırısı (Dictionary Attack)

- **Tanım:** Yaygın parolaların, kelimelerin ve bilinen parola kalıplarının denenmesidir.
- **Özellik:** Rastgele tüm olasılıkları denemek yerine olası parola listelerine odaklanır.
- **Savunma:** Uzun ve benzersiz parolalar, çok faktörlü kimlik doğrulama ve parola saklamada Argon2id/bcrypt gibi uygun algoritmalar kullanmak.

### 3. Yan Kanal Saldırısı (Side-Channel)

- **Tanım:** Kriptografik işlemin kendisinden ziyade uygulamanın fiziksel veya operasyonel davranışından bilgi elde etmeye çalışır.
- **Örnek:** Zamanlama, güç tüketimi, elektromanyetik yayılım veya önbellek davranışı.
- **Savunma:** Sabit zamanlı uygulamalar, güvenli donanım tasarımı, sızıntı azaltma teknikleri ve güvenlik testleri.

### 4. Bilinen Açık Metin Saldırısı (Known-Plaintext Attack)

- **Tanım:** Saldırganın bazı açık metinleri ve bunlara karşılık gelen şifreli metinleri bildiği varsayımına dayanır.
- **Amaç:** Bu eşleşmelerden anahtar veya başka açık metinler hakkında bilgi elde etmeye çalışmak.
- **Savunma:** Güvenli ve modern algoritmaların, doğru kip ve parametrelerle kullanılması.

### 5. Frekans Analizi (Frequency Analysis)

- **Tanım:** Şifreli metindeki harf veya sembol sıklıklarını inceleyerek açık metin hakkında tahmin yürütme yöntemidir.
- **Özellik:** Sezar ve basit yerine koyma şifreleri gibi klasik yöntemlere karşı etkilidir.
- **Savunma:** Modern kriptografik algoritmalar kullanmak.

### 6. Diferansiyel Kriptoanaliz (Differential Cryptanalysis)

- **Tanım:** Farklı açık metinler arasındaki değişimlerle bunların şifreli çıktılarındaki değişimleri inceleyen kriptoanaliz yaklaşımıdır.
- **Özellik:** Özellikle blok şifrelerin tasarım ve analizinde önemlidir.
- **Savunma:** Bu tür analizlere karşı dayanıklılığı değerlendirilmiş, güvenilir standart algoritmalar kullanmak.

### 7. Lineer Kriptoanaliz (Linear Cryptanalysis)

- **Tanım:** Açık metin, şifreli metin ve anahtar bitleri arasında yaklaşık doğrusal ilişkiler arar.
- **Özellik:** Blok şifrelerin analizinde kullanılan istatistiksel bir tekniktir.
- **Savunma:** Lineer kriptoanalize karşı dayanıklılığı analiz edilmiş algoritmalar kullanmak.

### 8. Ortadaki Adam Saldırısı (Man-in-the-Middle / MitM)

- **Tanım:** Saldırganın iki taraf arasındaki iletişime araya girerek müdahale etmesidir. Trafiği dinleyebilir veya değiştirebilir.
- **Özellik:** Bu saldırı doğrudan bir şifre çözme tekniği değildir; çoğunlukla kimlik doğrulama veya anahtar değişimi süreçlerindeki zayıflıklardan yararlanır.
- **Savunma:** Sertifika ve sunucu kimliği doğrulaması, güvenli anahtar anlaşması, güncel TLS ve uygun uçtan uca şifreleme kullanmak.

## Kullanım Alanları

- **Güvenlik değerlendirmesi:** Algoritma ve uygulama zayıflıklarını belirlemek.
- **Adli bilişim:** Yetki ve hukuki çerçeve içinde dijital delilleri analiz etmek.
- **Askerî ve istihbarat çalışmaları:** İletişim güvenliği ve sinyal istihbaratı araştırmaları.
- **Akademik araştırma:** Yeni algoritmaların dayanıklılığını değerlendirmek.

Kriptoanaliz teknikleri yalnızca saldırı amacıyla değil, kriptografik sistemlerin güvenliğini ölçmek ve geliştirmek için de kullanılır.
