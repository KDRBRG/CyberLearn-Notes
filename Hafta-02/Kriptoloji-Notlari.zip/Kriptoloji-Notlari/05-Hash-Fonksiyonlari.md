# Hash Fonksiyonları ve Hash Algoritmaları

Hash fonksiyonu, herhangi bir uzunluktaki girdiden sabit uzunlukta bir özet (hash) değeri üretir. Kriptografik hash fonksiyonları veri bütünlüğü, dijital imza ve çeşitli güvenlik mekanizmalarında kullanılır.

## Temel Özellikler

- **Deterministik:** Aynı girdi her zaman aynı özeti üretir.
- **Verimli:** Girdiden özet üretimi pratik olmalıdır.
- **Ön görüntü direnci (Preimage Resistance):** Verilen bir hash değerinden onu üreten girdiyi bulmak hesaplama açısından zor olmalıdır.
- **İkinci ön görüntü direnci:** Verilen bir girdiyle aynı hash değerini üreten farklı bir girdi bulmak zor olmalıdır.
- **Çarpışma direnci (Collision Resistance):** Herhangi iki farklı girdinin aynı özeti üretmesini sağlayan bir çift bulmak zor olmalıdır.
- **Avalanche etkisi:** Girdideki küçük bir değişiklik, çıktı bitlerinin büyük bölümünün değişmesine yol açmalıdır.

## Kullanım Alanları

- Dosya ve veri bütünlüğünün kontrol edilmesi
- Dijital imza süreçlerinde mesaj özeti oluşturulması
- Güvenli protokollerde bütünlük ve doğrulama mekanizmaları
- Veri yapıları ve indeksleme

### Parola Saklama Uyarısı

Parolalar, yalnızca SHA-256 veya MD5 gibi hızlı hash fonksiyonlarıyla saklanmamalıdır. Parola saklama için Argon2id, scrypt, bcrypt veya uygun yapılandırılmış PBKDF2 gibi yavaş ve parola odaklı algoritmalar; her parola için benzersiz salt ile kullanılmalıdır. Gerektiğinde pepper da ek bir savunma katmanı olabilir.

## Yaygın Hash Algoritmaları

### MD5

- 128 bit (16 bayt) özet üretir.
- Çarpışma saldırılarına karşı kırılmıştır.
- Güvenlik amacıyla kullanılmamalıdır.

### SHA-1

- 160 bit (20 bayt) özet üretir.
- Çarpışma direnci artık güvenli kabul edilmez.
- Yeni güvenlik tasarımlarında kullanılmamalıdır.

### SHA-2

- SHA-224, SHA-256, SHA-384 ve SHA-512 gibi algoritmaları içerir.
- Günümüzde yaygın olarak kullanılır.

### SHA-3

- Keccak ailesine dayanır ve SHA-2'den farklı bir iç yapıya sahiptir.
- Farklı çıktı uzunlukları sunar.

### RIPEMD-160

- 160 bit özet üretir.
- Bazı eski ve özel uygulamalarda görülür; yeni sistemlerde algoritma seçimi güncel güvenlik gereksinimlerine göre yapılmalıdır.

## Hash Saldırıları

- **Çarpışma saldırısı:** Aynı hash değerini üreten iki farklı girdi bulmaya çalışır.
- **Ön görüntü saldırısı:** Belirli bir hash değerini üreten girdiyi bulmaya çalışır.
- **Rainbow table saldırısı:** Önceden hesaplanmış özet tablolarından yararlanır. Benzersiz salt kullanımı bu tür tabloların etkisini büyük ölçüde azaltır.

> **Önemli:** Hash şifreleme değildir; normal anlamda geri çözülemez. Hash değerinin eşleşmesi tek başına kaynağın kimliğini kanıtlamaz. Kimlik doğrulama için HMAC veya dijital imza gibi uygun mekanizmalar gerekir.
