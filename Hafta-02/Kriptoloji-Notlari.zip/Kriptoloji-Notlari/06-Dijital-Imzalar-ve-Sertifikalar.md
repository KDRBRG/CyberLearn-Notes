# Dijital İmzalar ve Sertifikalar

Dijital imza, elektronik bir mesajın veya belgenin bütünlüğünü ve imzalayan özel anahtarın sahipliğini doğrulamaya yardımcı olan kriptografik yöntemdir.

## Dijital İmzaların Amaçları

- **Kimlik doğrulama:** İmzanın ilgili açık anahtarla doğrulandığını gösterir; anahtarın gerçek kişiyle ilişkisi ayrıca doğrulanmalıdır.
- **Bütünlük:** İmzalanan içerikte sonradan değişiklik yapılıp yapılmadığını tespit eder.
- **İnkâr edilemezlik:** Uygun hukuki, teknik ve operasyonel koşullarda imzalayanın işlemi inkâr etmesini zorlaştırır.

## Çalışma Prensibi

### İmza Oluşturma

1. İmzalanacak belge için güvenli bir hash fonksiyonuyla özet hesaplanır.
2. İmzalayanın özel anahtarı ve seçilen imza algoritması kullanılarak imza oluşturulur.
3. İmza, belgeyle birlikte alıcıya iletilir.

### İmza Doğrulama

1. Alıcı, gelen belgenin özetini aynı hash fonksiyonuyla hesaplar.
2. İmza, imzalayanın açık anahtarı ve ilgili doğrulama algoritmasıyla kontrol edilir.
3. Doğrulama başarılıysa imza, içeriğin imzadan sonra değiştirilmediğini ve ilgili özel anahtarın kullanıldığını destekler.

> **Düzeltme:** Dijital imza işlemi, genel olarak “hash değerini özel anahtarla şifrelemek” şeklinde açıklanmamalıdır. RSA-PSS, ECDSA ve EdDSA gibi algoritmalar farklı imzalama/doğrulama şemaları kullanır.

## Dijital İmza Algoritmaları

### RSA İmza

RSA, uygun imza şemaları (ör. RSA-PSS) kullanıldığında dijital imza oluşturma ve doğrulamada kullanılabilir.

### DSA

Dijital imza oluşturma ve doğrulama amacıyla tasarlanmıştır; genel amaçlı şifreleme algoritması değildir. Güncel standartlardaki kullanım durumu dikkate alınmalıdır.

### ECDSA

Eliptik eğri kriptografisine dayanan dijital imza algoritmasıdır. Görece kısa anahtarlarla güçlü güvenlik sağlayabilir.

### EdDSA

Edwards eğrilerine dayanan modern bir imza ailesidir. Ed25519 yaygın örneklerindendir.

## Dijital Sertifikalar ve PKI

Dijital sertifika, bir kimliği veya alan adını bir açık anahtarla ilişkilendirir. Sertifika, bir sertifika otoritesi (CA) tarafından dijital olarak imzalanır.

### Temel Kavramlar

- **X.509:** Yaygın dijital sertifika biçimini tanımlayan standart.
- **CA (Certificate Authority):** Sertifikaları imzalayan ve yayımlayan otorite.
- **RA (Registration Authority):** Başvuru ve kimlik doğrulama süreçlerine yardımcı olan kayıt otoritesi.
- **CRL (Certificate Revocation List):** İptal edilmiş sertifikaların listesidir.
- **OCSP (Online Certificate Status Protocol):** Sertifika durumunu çevrimiçi sorgulamak için kullanılan protokol.

## Kullanım Alanları

- E-posta imzalama ve şifreleme (PGP, S/MIME)
- Elektronik belge ve sözleşmeler
- Yazılım ve güncelleme imzalama
- Finansal işlemler
- E-Devlet ve e-ticaret hizmetleri

## Güvenlik İçin Dikkat Edilecekler

- Güvenilir ve güncel imza algoritmaları kullanılmalıdır.
- Özel anahtarlar güvenli biçimde saklanmalıdır.
- Sertifika geçerlilik süresi ve iptal durumu kontrol edilmelidir.
- Sertifika zinciri ve alan adı/kimlik bilgileri doğrulanmalıdır.
- Hash algoritması ve anahtar uzunluğu güncel standartlara uygun olmalıdır.
